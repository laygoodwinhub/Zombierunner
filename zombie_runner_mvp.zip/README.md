
# Zombie Runner MVP

A running-based zombie apocalypse mobile game built with:
- Expo / React Native
- Supabase
- TypeScript

## MVP Features
- GPS run tracking
- XP earning from distance
- Zombie story missions
- Base upgrades
- Inventory/resources

## Stack
- Expo Router
- React Native Maps
- Supabase Auth + Database
- Expo Location
- Zustand

## Quick Start

```bash
npm install
npx expo start
```

## Supabase Tables

### profiles
- id
- username
- xp
- level

### runs
- id
- user_id
- distance_km
- duration_seconds
- xp_earned

### bases
- id
- user_id
- wall_level
- storage_level

### missions
- id
- title
- description
- distance_required

## Core Gameplay Loop
1. Start a run
2. Track GPS movement
3. Trigger audio/text story events
4. Earn XP + scrap
5. Upgrade base
6. Unlock harder missions
