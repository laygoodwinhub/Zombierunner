
create table profiles (
  id uuid primary key,
  username text unique,
  xp int default 0,
  level int default 1
);

create table runs (
  id bigint generated always as identity primary key,
  user_id uuid references profiles(id),
  distance_km numeric,
  duration_seconds int,
  xp_earned int,
  created_at timestamp default now()
);

create table bases (
  id bigint generated always as identity primary key,
  user_id uuid references profiles(id),
  wall_level int default 1,
  storage_level int default 1
);

create table missions (
  id bigint generated always as identity primary key,
  title text,
  description text,
  distance_required numeric
);
