
# Zombie Runner Development Roadmap

## Phase 1 — MVP
- GPS tracking
- XP rewards
- Story missions
- Base upgrades

## Phase 2
- Multiplayer raids
- PvP leaderboards
- Zombie events

## Phase 3
- Voice acted missions
- AI-generated encounters
- Seasonal events
