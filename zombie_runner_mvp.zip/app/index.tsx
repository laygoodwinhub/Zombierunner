
import { View, Text, Button } from 'react-native';
import { useRouter } from 'expo-router';

export default function HomeScreen() {
  const router = useRouter();

  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 24 }}>
      <Text style={{ fontSize: 32, fontWeight: 'bold' }}>
        Zombie Runner
      </Text>

      <Text style={{ marginTop: 12 }}>
        Run in real life. Survive in-game.
      </Text>

      <Button
        title="Start Run"
        onPress={() => router.push('/run')}
      />

      <Button
        title="View Base"
        onPress={() => router.push('/base')}
      />
    </View>
  );
}
