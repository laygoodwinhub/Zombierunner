
import { View, Text, Button } from 'react-native';

export default function BaseScreen() {
  return (
    <View style={{ flex: 1, padding: 24 }}>
      <Text style={{ fontSize: 28 }}>Your Base</Text>

      <Text style={{ marginTop: 20 }}>
        Wall Level: 1
      </Text>

      <Text>
        Storage Level: 1
      </Text>

      <Button title="Upgrade Walls" onPress={() => {}} />
    </View>
  );
}
