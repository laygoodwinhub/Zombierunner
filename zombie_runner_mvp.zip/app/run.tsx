
import { useEffect, useState } from 'react';
import { View, Text, Button } from 'react-native';
import * as Location from 'expo-location';

export default function RunScreen() {
  const [distance, setDistance] = useState(0);

  useEffect(() => {
    requestLocation();
  }, []);

  async function requestLocation() {
    await Location.requestForegroundPermissionsAsync();
  }

  return (
    <View style={{ flex: 1, padding: 24 }}>
      <Text style={{ fontSize: 28 }}>Active Run</Text>

      <Text style={{ marginTop: 20 }}>
        Distance: {distance.toFixed(2)} km
      </Text>

      <Text style={{ marginTop: 12 }}>
        Zombie horde detected ahead...
      </Text>

      <Button title="Finish Run" onPress={() => {}} />
    </View>
  );
}
